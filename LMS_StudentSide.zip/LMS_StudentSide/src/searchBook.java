import java.awt.Color;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;

import net.proteanit.sql.DbUtils;
import java.awt.SystemColor;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class searchBook extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					searchBook frame = new searchBook();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	private JTable table;
	private JTextField textField;
	
	public void Connect() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db_library", "root","");
			
			
		}
		catch(ClassNotFoundException ex){ 
			System.out.println(ex);
		}
		catch(SQLException ex){
			System.out.println(ex);
		}
	}
	

	
	public void table_load()
	{
		try {
			String query= "select * from tbl_catalog";
			pst =con.prepareStatement(query);
			rs = pst.executeQuery(query);
			table.setModel(DbUtils.resultSetToTableModel(rs));
		}
		catch (Exception e)
		{
			JOptionPane.showMessageDialog(null, e);
		}
	}

	/**
	 * Create the frame.
	 */
	public searchBook() {
		Connect();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 986, 800);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(230,230,230));
		setLocationRelativeTo(null);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setUndecorated(true);
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 116, 968, 678);
		contentPane.add(scrollPane);
		
		JPanel panel = new JPanel();
		scrollPane.setViewportView(panel);
		panel.setLayout(null);
		
		table = new JTable();
		table.setBounds(0, 0, 968, 678);
		panel.add(table);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(SystemColor.windowBorder);
		panel_1.setBounds(10, 81, 968, 713);
		contentPane.add(panel_1);
		
		JLabel lblBookID_1 = new JLabel("Book ID");
		lblBookID_1.setForeground(Color.WHITE);
		lblBookID_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBookID_1.setBounds(10, 10, 70, 22);
		panel_1.add(lblBookID_1);
		
		JLabel lblBookID_1_1 = new JLabel("Title");
		lblBookID_1_1.setForeground(Color.WHITE);
		lblBookID_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBookID_1_1.setBounds(94, 10, 70, 22);
		panel_1.add(lblBookID_1_1);
		
		JLabel lblBookID_1_2 = new JLabel("ISBN");
		lblBookID_1_2.setForeground(Color.WHITE);
		lblBookID_1_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBookID_1_2.setBounds(185, 10, 70, 22);
		panel_1.add(lblBookID_1_2);
		
		JLabel lblBookID_1_3 = new JLabel("Author");
		lblBookID_1_3.setForeground(Color.WHITE);
		lblBookID_1_3.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBookID_1_3.setBounds(266, 10, 70, 22);
		panel_1.add(lblBookID_1_3);
		
		JLabel lblBookID_1_4 = new JLabel("Version");
		lblBookID_1_4.setForeground(Color.WHITE);
		lblBookID_1_4.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBookID_1_4.setBounds(360, 10, 70, 22);
		panel_1.add(lblBookID_1_4);
		
		JLabel lblBookID_1_5 = new JLabel("Publisher");
		lblBookID_1_5.setForeground(Color.WHITE);
		lblBookID_1_5.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBookID_1_5.setBounds(440, 10, 70, 22);
		panel_1.add(lblBookID_1_5);
		
		JLabel lblBookID_1_6 = new JLabel("Place");
		lblBookID_1_6.setForeground(Color.WHITE);
		lblBookID_1_6.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBookID_1_6.setBounds(530, 10, 70, 22);
		panel_1.add(lblBookID_1_6);
		
		JLabel lblBookID_1_6_1 = new JLabel("Year");
		lblBookID_1_6_1.setForeground(Color.WHITE);
		lblBookID_1_6_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBookID_1_6_1.setBounds(617, 10, 70, 22);
		panel_1.add(lblBookID_1_6_1);
		
		JLabel lblBookID_1_6_1_1 = new JLabel("Pages");
		lblBookID_1_6_1_1.setForeground(Color.WHITE);
		lblBookID_1_6_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBookID_1_6_1_1.setBounds(707, 10, 48, 22);
		panel_1.add(lblBookID_1_6_1_1);
		
		JLabel lblBookID_1_6_1_2 = new JLabel("Categories");
		lblBookID_1_6_1_2.setForeground(Color.WHITE);
		lblBookID_1_6_1_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblBookID_1_6_1_2.setBounds(797, 10, 114, 22);
		panel_1.add(lblBookID_1_6_1_2);
		
		JLabel iconRefresh = new JLabel("");
		iconRefresh.setHorizontalAlignment(SwingConstants.CENTER);
		iconRefresh.setBounds(921, 0, 45, 32);
		panel_1.add(iconRefresh);
		
		JLabel lblNewLabel = new JLabel("X");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				searchBook.this.dispose();
				
			}
		});
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(941, 0, 45, 45);
		contentPane.add(lblNewLabel);
		
		JPanel panel_4 = new JPanel();
		panel_4.setLayout(null);
		panel_4.setBackground(SystemColor.windowBorder);
		panel_4.setBounds(10, 30, 275, 41);
		contentPane.add(panel_4);
		
		JLabel iconSearch = new JLabel("");
		iconSearch.setHorizontalAlignment(SwingConstants.CENTER);
		Image imgSearch = new ImageIcon(this.getClass().getResource("/imgsearch.png")).getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
		iconSearch.setIcon(new ImageIcon(imgSearch));
		iconSearch.setBounds(0, 0, 46, 41);
		panel_4.add(iconSearch);
		
		textField = new JTextField();
		textField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyReleased(KeyEvent e) {
				try {
					
					
					String searchTemp = textField.getText() + "%";
					pst = con.prepareStatement("select book_id,Title,ISBN,author,version,publisher,place_published,year_published,pages,category_1,category_2  from tbl_catalog "+
				             "WHERE book_id LIKE '%" + searchTemp + "%' OR " +
				                   "Title LIKE '%" + searchTemp + "%' OR " +
				                   "ISBN LIKE '%" + searchTemp + "%' OR " +
				                   "author LIKE '%" + searchTemp + "%' OR " +
				                   "version LIKE '%" + searchTemp + "%' OR " +
				                   "publisher LIKE '%" + searchTemp + "%' OR " +
				                   "place_published LIKE '%" + searchTemp + "%' OR " +
				                   "year_published LIKE '%" + searchTemp + "%' OR " +
				                   "pages LIKE '%" + searchTemp + "%' OR " +
				                   "category_1 LIKE '%" + searchTemp + "%' OR " +
				                   "category_2 LIKE '%" + searchTemp + "%'");
				
					ResultSet rs= pst.executeQuery();
					table.setModel(DbUtils.resultSetToTableModel(rs));
					
				
				}
				catch (Exception ex){
				ex.printStackTrace();
				}
				
				

			}
		});
		textField.setColumns(10);
		textField.setBounds(46, 0, 229, 41);
		panel_4.add(textField);
		
		table_load();
		
	}

}
