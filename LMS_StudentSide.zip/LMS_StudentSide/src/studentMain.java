import java.awt.EventQueue;



import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Image;
import java.awt.SystemColor;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.swing.border.LineBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class studentMain extends JFrame {
	private JLabel lblClock;

	private JPanel contentPane;
	Thread th;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					studentMain frame = new studentMain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public void Clock() {
		Thread clock = new  Thread() 
		{
			public void run() 
			{
				try {
				for(;;) {
					Calendar cal = new GregorianCalendar();
					
					int second=cal.get(Calendar.SECOND);
					int minute=cal.get(Calendar.MINUTE);
					int hour=cal.get(Calendar.HOUR);
					int AMPM = cal.get(Calendar.AM_PM);
					String AM = (" A.M");
					String PM = (" P.M");
					
					
					
					
					if(AMPM == 0) {
						lblClock.setText(hour+":"+minute+":"+second + AM);
					}else {
						lblClock.setText(hour+":"+minute+":"+second +PM);
					}
				

					sleep(1000);
				}
				}catch(InterruptedException e) {
					e.printStackTrace();
				}
				
				
			}
		
		};
		clock.start();
	}
	

	/**
	 * Create the frame.
	 */
	public studentMain() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1566, 866);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0,200,119));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setUndecorated(true);
		setExtendedState(JFrame.MAXIMIZED_BOTH);

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBorder(new EmptyBorder(0, 0, 0, 0));
		panel.setBounds(0, 0, 839, 866);
		contentPane.add(panel);
		
		JPanel panel_1_3 = new JPanel();
		panel_1_3.setBackground(new Color(45, 21, 117));
		panel_1_3.setBounds(792, 0, 10, 866);
		panel.add(panel_1_3);
		
		JPanel panel_1_1_1 = new JPanel();
		panel_1_1_1.setBackground(new Color(207, 40, 32));
		panel_1_1_1.setBounds(738, 0, 10, 866);
		panel.add(panel_1_1_1);
		
		JPanel panel_1_2_1 = new JPanel();
		panel_1_2_1.setBackground(new Color(235, 199, 25));
		panel_1_2_1.setBounds(682, 0, 10, 866);
		panel.add(panel_1_2_1);
		
		JLabel iconLogo = new JLabel("");
		iconLogo.setHorizontalAlignment(SwingConstants.CENTER);
		Image imglogo = new ImageIcon(this.getClass().getResource("/imglogo.png")).getImage().getScaledInstance(350, 350, Image.SCALE_SMOOTH);
		iconLogo.setIcon(new ImageIcon(imglogo));
		iconLogo.setBounds(140, 156, 412, 489);
		panel.add(iconLogo);
		
		JLabel lblNewLabel = new JLabel("Digital Library");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(SystemColor.windowBorder);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 40));
		lblNewLabel.setBounds(150, 597, 402, 55);
		panel.add(lblNewLabel);
		
		JPanel btnAttendance = new JPanel();
		btnAttendance.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				studentAttendance.main(null);
			}
		});
		btnAttendance.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnAttendance.setBackground(new Color(1, 177, 104));
		btnAttendance.setBounds(933, 224, 534, 124);
		contentPane.add(btnAttendance);
		btnAttendance.setLayout(null);
		
		JLabel iconAttendance = new JLabel("");
		Image imgAttendance = new ImageIcon(this.getClass().getResource("/imgqr.png")).getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);
		iconAttendance.setIcon(new ImageIcon(imgAttendance));
		iconAttendance.setHorizontalAlignment(SwingConstants.CENTER);
		iconAttendance.setBounds(10, 10, 123, 104);
		btnAttendance.add(iconAttendance);
		
		JLabel lblNewLabel_1 = new JLabel("Attendance");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel_1.setBounds(143, 10, 381, 104);
		btnAttendance.add(lblNewLabel_1);
		
		JPanel btnSearch = new JPanel();
		btnSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				searchBook search = new searchBook();
				search.show();
			}
		});
		btnSearch.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		btnSearch.setBackground(new Color(1, 177, 104));
		btnSearch.setBounds(933, 404, 534, 124);
		contentPane.add(btnSearch);
		btnSearch.setLayout(null);
		
		JLabel iconSearch = new JLabel("");
		Image imgSearch = new ImageIcon(this.getClass().getResource("/imgsearch.png")).getImage().getScaledInstance(110, 110, Image.SCALE_SMOOTH);
		iconSearch.setIcon(new ImageIcon(imgSearch));
		iconSearch.setHorizontalAlignment(SwingConstants.CENTER);
		iconSearch.setBounds(10, 10, 123, 104);
		btnSearch.add(iconSearch);
		
		JLabel lblNewLabel_1_1 = new JLabel("Search Book");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setForeground(Color.WHITE);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 30));
		lblNewLabel_1_1.setBounds(143, 10, 381, 104);
		btnSearch.add(lblNewLabel_1_1);
		
		lblClock = new JLabel("");
		lblClock.setHorizontalAlignment(SwingConstants.TRAILING);
		lblClock.setForeground(new Color(255, 255, 255));
		lblClock.setFont(new Font("Tahoma", Font.PLAIN, 50));
		lblClock.setBounds(1189, 758, 338, 98);
		contentPane.add(lblClock);
		
		Clock();
		th = new Thread();
		th.start();
	}
}
